export function  Select(props: {characterData:any}){
	const {characterData} = props;

	console.log(new Set(characterData.map((item: {type:string}) => item.type)))
	return (
		<select multiple >
			{
			}
		</select>
	)
}