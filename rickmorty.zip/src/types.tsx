import { ChangeEventHandler } from "react";

export interface CharacterArray {
    id: number,
    name: string,
    status: string,
    species: string,
    type: string,
    gender: string,
    origin: {
      name: string,
      url: string
    },
    location: {
      name: string,
      url: string
    },
    image: string,
    episode: Array<string>,
    url: string,
    created: string
}

// type innerObject = {
//   name: string,
//   url: string
// }

// export interface chrt {
//   [key: string]: string|number|innerObject|Array<string>,
// }

export interface FilterPropsType {
  id?:string,
  item?:string,
  filterName:string,
  type:string,
  isChecked?:boolean,
  onChange?:ChangeEventHandler<HTMLInputElement> | undefined
}

export interface OptionArray  {
  "label": string,
  "value": string
}